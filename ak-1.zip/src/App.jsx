import { useState, useRef, useEffect } from 'react'
import {
  Upload,
  Link as LinkIcon,
  FileText,
  Mic,
  Send,
  Play,
  Settings,
  ArrowRight,
  Volume2,
  X,
  Share2,
  Captions
} from 'lucide-react'
import teacherAvatar from './assets/tutor_avatar.png'
import './App.css'

// ---------------- API Configuration ----------------
const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY || ''
// gemini-1.5-flash was retired by Google (404). Use current models with fallback.
const MODEL_CHAIN = ['gemini-flash-latest', 'gemini-2.5-flash', 'gemini-2.0-flash']
const GL_BASE = 'https://generativelanguage.googleapis.com/v1beta/models'
let workingModel = null

async function geminiGenerate(body) {
  if (!GEMINI_API_KEY) throw new Error('Missing VITE_GEMINI_API_KEY in .env')
  const models = workingModel
    ? [workingModel, ...MODEL_CHAIN.filter(m => m !== workingModel)]
    : MODEL_CHAIN
  let lastErr = null
  for (const model of models) {
    try {
      const res = await fetch(`${GL_BASE}/${model}:generateContent?key=${GEMINI_API_KEY}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      })
      if (res.ok) {
        workingModel = model
        return await res.json()
      }
      const errJson = await res.json().catch(() => ({}))
      const msg = errJson?.error?.message || `HTTP ${res.status}`
      if (res.status === 404) { lastErr = new Error(msg); continue } // model retired - try next
      throw new Error(msg)
    } catch (e) {
      lastErr = e
      if (e instanceof TypeError) continue // network error - try next attempt
      if (!String(e.message).includes('not found')) throw e
    }
  }
  throw lastErr || new Error('All Gemini models failed')
}

const extractText = (data) =>
  (data?.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('')

// ---------------- Cloud TTS (Gemini) - speaks ALL languages with a consistent FEMALE voice ----------------
// Browser speechSynthesis only knows the voices installed on the device (often just
// Hindi/English on Windows). Gemini TTS generates the audio itself, so every language works.
const TTS_MODELS = ['gemini-2.5-flash-preview-tts', 'gemini-3.1-flash-tts-preview']
const TTS_VOICE = 'Kore' // female voice
let workingTtsModel = null

const pcmBase64ToWavUrl = (b64, sampleRate) => {
  const bin = atob(b64)
  const pcm = new Uint8Array(bin.length)
  for (let i = 0; i < bin.length; i++) pcm[i] = bin.charCodeAt(i)
  const header = new ArrayBuffer(44)
  const v = new DataView(header)
  const w = (off, str) => { for (let i = 0; i < str.length; i++) v.setUint8(off + i, str.charCodeAt(i)) }
  w(0, 'RIFF'); v.setUint32(4, 36 + pcm.length, true); w(8, 'WAVE'); w(12, 'fmt ')
  v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true)
  v.setUint32(24, sampleRate, true); v.setUint32(28, sampleRate * 2, true)
  v.setUint16(32, 2, true); v.setUint16(34, 16, true)
  w(36, 'data'); v.setUint32(40, pcm.length, true)
  return URL.createObjectURL(new Blob([header, pcm], { type: 'audio/wav' }))
}

async function geminiSpeak(text) {
  if (!GEMINI_API_KEY) throw new Error('Missing API key')
  const models = workingTtsModel ? [workingTtsModel, ...TTS_MODELS.filter(m => m !== workingTtsModel)] : TTS_MODELS
  let lastErr = null
  for (const model of models) {
    try {
      const res = await fetch(`${GL_BASE}/${model}:generateContent?key=${GEMINI_API_KEY}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text }] }],
          generationConfig: {
            responseModalities: ['AUDIO'],
            speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: TTS_VOICE } } }
          }
        })
      })
      if (!res.ok) {
        const j = await res.json().catch(() => ({}))
        lastErr = new Error(j?.error?.message || `HTTP ${res.status}`)
        continue
      }
      const data = await res.json()
      const part = data?.candidates?.[0]?.content?.parts?.find(pt => pt.inlineData?.data)
      if (!part) { lastErr = new Error('No audio returned'); continue }
      workingTtsModel = model
      const rate = Number((part.inlineData.mimeType.match(/rate=(\d+)/) || [])[1] || 24000)
      return pcmBase64ToWavUrl(part.inlineData.data, rate)
    } catch (e) { lastErr = e }
  }
  throw lastErr || new Error('TTS failed')
}

// ---------------- Transcript translation (any language) ----------------
async function translateTexts(texts, langName, langCode) {
  const out = []
  for (let i = 0; i < texts.length; i += 80) {
    const chunk = texts.slice(i, i + 80)
    const data = await geminiGenerate({
      contents: [{
        role: 'user',
        parts: [{
          text: `Translate every string in this JSON array into ${langName} (${langCode}). ` +
            'Return ONLY a JSON array with the SAME number of items, in the same order, containing only the translations.\n' +
            JSON.stringify(chunk)
        }]
      }],
      generationConfig: { responseMimeType: 'application/json', temperature: 0, maxOutputTokens: 16384 }
    })
    const arr = JSON.parse(extractText(data).replace(/^```json\s*/i, '').replace(/```\s*$/, '').trim())
    if (!Array.isArray(arr) || arr.length !== chunk.length) throw new Error('Translation mismatch')
    out.push(...arr.map(x => String(x)))
  }
  return out
}

// ---------------- Helpers ----------------
const stripEmojis = (text) => {
  if (!text) return ''
  return text
    .replace(/\p{Emoji_Presentation}/gu, '')
    .replace(/[\u{1F300}-\u{1F9FF}]/gu, '')
    .replace(/[\u{2600}-\u{27BF}]/gu, '')
    .replace(/[\u{1F600}-\u{1F64F}]/gu, '')
    .replace(/[\u{1F680}-\u{1F6FF}]/gu, '')
    .trim()
}

// Remove markdown so it is neither displayed raw nor read aloud as "asterisk"
const cleanText = (text) => {
  if (!text) return ''
  return text
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/\*([^*]+)\*/g, '$1')
    .replace(/__([^_]+)__/g, '$1')
    .replace(/`{1,3}([^`]*)`{1,3}/g, '$1')
    .replace(/^#{1,6}\s+/gm, '')
    .replace(/^\s*[-•]\s+/gm, '- ')
    .trim()
}

// Chrome cuts off long utterances - split into sentence chunks
const chunkForSpeech = (text, maxLen = 180) => {
  const sentences = text.split(/(?<=[.!?।՞؟])\s+|\n+/).map(s => s.trim()).filter(Boolean)
  const chunks = []
  let cur = ''
  for (const s of sentences) {
    if ((cur + ' ' + s).trim().length <= maxLen) cur = (cur + ' ' + s).trim()
    else {
      if (cur) chunks.push(cur)
      if (s.length <= maxLen) cur = s
      else {
        for (let i = 0; i < s.length; i += maxLen) chunks.push(s.slice(i, i + maxLen))
        cur = ''
      }
    }
  }
  if (cur) chunks.push(cur)
  return chunks
}

const parseYouTubeId = (url) => {
  if (!url) return ''
  try {
    if (url.includes('youtu.be/')) return url.split('youtu.be/')[1].split(/[?#&]/)[0]
    if (url.includes('/shorts/')) return url.split('/shorts/')[1].split(/[?#&]/)[0]
    if (url.includes('youtube.com/watch')) return new URLSearchParams(new URL(url).search).get('v') || ''
    if (url.includes('embed/')) return url.split('embed/')[1].split(/[?#&]/)[0]
  } catch { return '' }
  return ''
}

const formatTime = (sec) => {
  const s = Math.max(0, Math.floor(sec))
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`
}

const SUPPORTED_LANGUAGES = [
  { code: 'hi-IN', name: 'Hindi (हिन्दी)' },
  { code: 'en-IN', name: 'English (India)' },
  { code: 'en-US', name: 'English (US)' },
  { code: 'en-GB', name: 'English (UK)' },
  { code: 'bn-IN', name: 'Bengali (বাংলা)' },
  { code: 'mr-IN', name: 'Marathi (मराठी)' },
  { code: 'ta-IN', name: 'Tamil (தமிழ்)' },
  { code: 'te-IN', name: 'Telugu (తెలుగు)' },
  { code: 'kn-IN', name: 'Kannada (ಕನ್ನಡ)' },
  { code: 'ml-IN', name: 'Malayalam (മലയാളം)' },
  { code: 'gu-IN', name: 'Gujarati (ગુજરાતી)' },
  { code: 'pa-IN', name: 'Punjabi (ਪੰਜਾਬੀ)' },
  { code: 'ur-IN', name: 'Urdu (اردو)' },
  { code: 'or-IN', name: 'Odia (ଓଡ଼ିଆ)' },
  { code: 'as-IN', name: 'Assamese (অসমীয়া)' },
  { code: 'ne-NP', name: 'Nepali (नेपाली)' },
  { code: 'si-LK', name: 'Sinhala (සිංහල)' },
  { code: 'es-ES', name: 'Spanish (Español)' },
  { code: 'es-MX', name: 'Spanish - Mexico (Español)' },
  { code: 'pt-BR', name: 'Portuguese - Brazil (Português)' },
  { code: 'pt-PT', name: 'Portuguese (Português)' },
  { code: 'fr-FR', name: 'French (Français)' },
  { code: 'de-DE', name: 'German (Deutsch)' },
  { code: 'it-IT', name: 'Italian (Italiano)' },
  { code: 'nl-NL', name: 'Dutch (Nederlands)' },
  { code: 'ru-RU', name: 'Russian (Русский)' },
  { code: 'uk-UA', name: 'Ukrainian (Українська)' },
  { code: 'pl-PL', name: 'Polish (Polski)' },
  { code: 'cs-CZ', name: 'Czech (Čeština)' },
  { code: 'sk-SK', name: 'Slovak (Slovenčina)' },
  { code: 'ro-RO', name: 'Romanian (Română)' },
  { code: 'hu-HU', name: 'Hungarian (Magyar)' },
  { code: 'el-GR', name: 'Greek (Ελληνικά)' },
  { code: 'bg-BG', name: 'Bulgarian (Български)' },
  { code: 'sr-RS', name: 'Serbian (Српски)' },
  { code: 'hr-HR', name: 'Croatian (Hrvatski)' },
  { code: 'sv-SE', name: 'Swedish (Svenska)' },
  { code: 'nb-NO', name: 'Norwegian (Norsk)' },
  { code: 'da-DK', name: 'Danish (Dansk)' },
  { code: 'fi-FI', name: 'Finnish (Suomi)' },
  { code: 'tr-TR', name: 'Turkish (Türkçe)' },
  { code: 'ar-SA', name: 'Arabic (العربية)' },
  { code: 'he-IL', name: 'Hebrew (עברית)' },
  { code: 'fa-IR', name: 'Persian (فارسی)' },
  { code: 'sw-KE', name: 'Swahili (Kiswahili)' },
  { code: 'am-ET', name: 'Amharic (አማርኛ)' },
  { code: 'af-ZA', name: 'Afrikaans' },
  { code: 'zu-ZA', name: 'Zulu (isiZulu)' },
  { code: 'id-ID', name: 'Indonesian (Bahasa Indonesia)' },
  { code: 'ms-MY', name: 'Malay (Bahasa Melayu)' },
  { code: 'vi-VN', name: 'Vietnamese (Tiếng Việt)' },
  { code: 'th-TH', name: 'Thai (ไทย)' },
  { code: 'fil-PH', name: 'Filipino (Tagalog)' },
  { code: 'km-KH', name: 'Khmer (ខ្មែរ)' },
  { code: 'my-MM', name: 'Burmese (မြန်မာ)' },
  { code: 'lo-LA', name: 'Lao (ລາວ)' },
  { code: 'zh-CN', name: 'Chinese - Simplified (中文)' },
  { code: 'zh-TW', name: 'Chinese - Traditional (中文)' },
  { code: 'zh-HK', name: 'Cantonese (廣東話)' },
  { code: 'ja-JP', name: 'Japanese (日本語)' },
  { code: 'ko-KR', name: 'Korean (한국어)' },
  { code: 'kk-KZ', name: 'Kazakh (Қазақша)' },
  { code: 'uz-UZ', name: 'Uzbek (Oʻzbekcha)' },
  { code: 'az-AZ', name: 'Azerbaijani (Azərbaycanca)' },
  { code: 'ka-GE', name: 'Georgian (ქართული)' },
  { code: 'hy-AM', name: 'Armenian (Հայերեն)' },
  { code: 'mn-MN', name: 'Mongolian (Монгол)' }
]

const resolveSupported = (lang) => {
  if (!lang) return null
  const exact = SUPPORTED_LANGUAGES.find(l => l.code.toLowerCase() === lang.toLowerCase())
  if (exact) return exact.code
  const prefix = lang.split('-')[0].toLowerCase()
  const pref = SUPPORTED_LANGUAGES.find(l => l.code.split('-')[0].toLowerCase() === prefix)
  return pref ? pref.code : null
}

// Timed transcript via Gemini (the old subtitles-youtube.vercel.app endpoint is dead)
const transcriptCache = new Map()
const fetchYouTubeTranscript = (videoId) => {
  if (transcriptCache.has(videoId)) return transcriptCache.get(videoId)
  const promise = (async () => {
    const body = {
      contents: [{
        role: 'user',
        parts: [
          { fileData: { fileUri: `https://www.youtube.com/watch?v=${videoId}` } },
          {
            text: 'Transcribe ALL spoken audio of this video in its ORIGINAL language. ' +
              'Return ONLY a JSON array covering the whole video, in chronological order: ' +
              '[{"start": <number, seconds when this speech begins>, "text": "<spoken words>"}]. ' +
              'Each segment should be about 4-10 seconds of speech. No translation, no commentary.'
          }
        ]
      }],
      generationConfig: { responseMimeType: 'application/json', temperature: 0 }
    }
    const data = await geminiGenerate(body)
    const raw = extractText(data).replace(/^```json\s*/i, '').replace(/```\s*$/, '').trim()
    const arr = JSON.parse(raw)
    if (!Array.isArray(arr)) throw new Error('Bad transcript format')
    const segs = arr
      .filter(s => s && typeof s.text === 'string' && s.text.trim() && !isNaN(Number(s.start)))
      .map(s => ({ start: Number(s.start), text: s.text.trim() }))
      .sort((a, b) => a.start - b.start)
    return segs.map((s, i) => ({ ...s, end: i < segs.length - 1 ? segs[i + 1].start : s.start + 6 }))
  })()
  promise.catch(() => transcriptCache.delete(videoId))
  transcriptCache.set(videoId, promise)
  return promise
}

// ---------------- Uploaded transcript parsing (.srt / .vtt / .txt / .json) ----------------
const tsToSeconds = (h, m, sec, ms) => (Number(h) || 0) * 3600 + (Number(m) || 0) * 60 + (Number(sec) || 0) + (Number(String(ms || '0').padEnd(3, '0').slice(0, 3)) || 0) / 1000

const parseCueFile = (content) => {
  // Handles both SRT and WebVTT
  const lines = content.replace(/\r/g, '').split('\n')
  const cueRe = /(?:(\d{1,2}):)?(\d{1,2}):(\d{2})[.,](\d{1,3})\s*-->\s*(?:(\d{1,2}):)?(\d{1,2}):(\d{2})[.,](\d{1,3})/
  const segs = []
  let i = 0
  while (i < lines.length) {
    const m = lines[i].match(cueRe)
    if (m) {
      const start = tsToSeconds(m[1], m[2], m[3], m[4])
      const end = tsToSeconds(m[5], m[6], m[7], m[8])
      const textLines = []
      i++
      while (i < lines.length && lines[i].trim() !== '' && !lines[i].match(cueRe)) {
        textLines.push(lines[i].replace(/<[^>]+>/g, '').trim())
        i++
      }
      const text = textLines.join(' ').trim()
      if (text) segs.push({ start, end, text })
    } else i++
  }
  return segs
}

const parseUploadedTranscript = (fileName, content) => {
  const name = fileName.toLowerCase()
  try {
    if (name.endsWith('.json')) {
      const arr = JSON.parse(content)
      if (Array.isArray(arr)) {
        const toSec = (v) => {
          if (typeof v === 'number') return v
          if (typeof v === 'string' && v.includes(':')) {
            const p = v.split(':').map(Number)
            return p.length === 3 ? p[0] * 3600 + p[1] * 60 + p[2] : p[0] * 60 + p[1]
          }
          return Number(v)
        }
        const segs = arr
          .filter(x => x && typeof x.text === 'string' && x.text.trim())
          .map(x => ({ start: toSec(x.start ?? x.offset ?? 0), text: x.text.trim(), end: x.end != null ? toSec(x.end) : undefined }))
          .filter(x => !isNaN(x.start))
          .sort((a, b) => a.start - b.start)
          .map((x, i2, all) => ({ ...x, end: x.end ?? (i2 < all.length - 1 ? all[i2 + 1].start : x.start + 6) }))
        if (segs.length) return { segs, text: segs.map(x => x.text).join(' ') }
      }
    }
  } catch { /* fall through to other formats */ }
  if (content.includes('-->')) {
    const segs = parseCueFile(content)
    if (segs.length) return { segs, text: segs.map(x => x.text).join(' ') }
  }
  return { segs: null, text: content.replace(/\s+/g, ' ').trim() }
}

// ---------------- Female voice preference (Ms. Anjali is a female teacher) ----------------
const FEMALE_HINTS = ['female', 'woman', 'zira', 'aria', 'jenny', 'heera', 'kalpana', 'swara', 'neerja', 'veena', 'lekha', 'samantha', 'victoria', 'karen', 'moira', 'fiona', 'tessa', 'sonia', 'natasha', 'hazel', 'susan', 'salli', 'joanna', 'kendra', 'ivy', 'raveena', 'aditi', 'kajal', 'ananya', 'priya', 'shruti', 'isha', 'sara', 'laura', 'anna', 'emma', 'mia', 'carla', 'paulina', 'monica', 'luciana', 'amelie', 'audrey', 'celine', 'katja', 'marlene', 'vicki', 'alice', 'elsa', 'irina', 'milena', 'yuna', 'kyoko', 'meijia', 'tingting', 'damayanti', 'nora', 'ida', 'alva', 'klara', 'ewa', 'maja', 'carmit', 'nurit', 'laila', 'mariam', 'zeina', 'amira', 'banu', 'filiz', 'zosia', 'sin-ji', 'mei-jia', 'ting-ting']
const MALE_HINTS = ['david', 'mark ', 'james', 'george', 'ravi', 'hemant', 'prabhat', 'madhur', 'valluvar', 'daniel', 'thomas', 'diego', 'jorge', 'juan', 'xander', 'yannick', 'stefan', 'felipe', 'maged', 'tarik', 'aaron', 'guy ', 'pavel', 'maxim', 'dmitri', 'rishi', 'gordon', 'arthur', 'liam', 'oliver']
const voiceScore = (v) => {
  const n = ` ${v.name.toLowerCase()} `
  let score = 0
  if (FEMALE_HINTS.some(h => n.includes(h))) score += 6
  else if (n.includes('male') && !n.includes('female')) score -= 6
  else if (MALE_HINTS.some(h => n.includes(h))) score -= 6
  if (n.includes('google')) score += 2 // Chrome Google voices are female for most languages
  if (n.includes('natural') || n.includes('neural') || n.includes('online')) score += 1
  return score
}

const DEFAULT_VIDEO_ID = 'tgbNymZ7vqY'
const DEFAULT_TITLE = 'No 4 Stay Calm in Their Storms Tarun Hindi'

function App() {
  // Video source: YouTube id OR local/direct URL
  const [videoId, setVideoId] = useState(DEFAULT_VIDEO_ID)
  const [localUrl, setLocalUrl] = useState('')
  const [videoTitle, setVideoTitle] = useState(DEFAULT_TITLE)
  const [isVideoStarted, setIsVideoStarted] = useState(false)
  const isYouTube = !!videoId

  const [selectedLanguage, setSelectedLanguage] = useState('hi-IN')
  const [isThinking, setIsThinking] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const [isTeacherSpeaking, setIsTeacherSpeaking] = useState(false)
  const [isContinuous, setIsContinuous] = useState(false)
  const [showChatInput, setShowChatInput] = useState(false)
  const [typedMessage, setTypedMessage] = useState('')
  const [inputUrl, setInputUrl] = useState('')
  const [modalMode, setModalMode] = useState(null)

  // Transcript feature
  const [showTranscript, setShowTranscript] = useState(false)
  const [transcriptSegs, setTranscriptSegs] = useState([])
  const [transcriptStatus, setTranscriptStatus] = useState('loading') // loading|ready|unavailable
  const [transcriptPlainText, setTranscriptPlainText] = useState('')
  const [transcriptLang, setTranscriptLang] = useState('original')
  const [translations, setTranslations] = useState({}) // { langCode: { segs, plain } }
  const [isTranslating, setIsTranslating] = useState(false)
  const [playTime, setPlayTime] = useState(0)

  const [chatLog, setChatLog] = useState([
    {
      id: 1,
      sender: 'MS. ANJALI',
      message: "Hello children! Welcome to our classroom. I am Ms. Anjali, your teacher today. Tap Ask to talk to me, or Write to type a question. You can talk to me in any language - I will answer in the same language. Let's watch the video and learn together!"
    },
    {
      id: 2,
      sender: 'MS. ANJALI',
      message: `New lesson loaded: ${DEFAULT_TITLE}. Let's learn!`
    }
  ])

  const chatTopRef = useRef(null)
  const fileInputRef = useRef(null)
  const transcriptFileRef = useRef(null)
  const uploadedTranscriptRef = useRef(false)
  const currentAudioRef = useRef(null)
  const recognitionRef = useRef(null)
  const videoElRef = useRef(null)
  const ytPlayerRef = useRef(null)
  const activeSegRef = useRef(null)
  const objectUrlRef = useRef('')

  // Refs mirror state used inside async callbacks (fixes stale-closure bugs
  // that broke continuous voice mode in the old version)
  const continuousRef = useRef(false)
  const thinkingRef = useRef(false)
  const ttsActiveRef = useRef(false)
  const ttsSeqRef = useRef(0)
  const activeLangRef = useRef('hi-IN')
  const convoRef = useRef([]) // [{role:'user'|'model', text}]
  const transcriptTextRef = useRef('')
  const videoTitleRef = useRef(DEFAULT_TITLE)
  const voicesRef = useRef([])
  const genSeqRef = useRef(0)

  useEffect(() => { videoTitleRef.current = videoTitle }, [videoTitle])
  useEffect(() => { chatTopRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [chatLog, isThinking])

  // Load speech-synthesis voices (they arrive asynchronously)
  useEffect(() => {
    if (!('speechSynthesis' in window)) return
    const load = () => { voicesRef.current = window.speechSynthesis.getVoices() }
    load()
    window.speechSynthesis.addEventListener('voiceschanged', load)
    return () => window.speechSynthesis.removeEventListener('voiceschanged', load)
  }, [])

  const pushMessage = (sender, message, isError = false) =>
    setChatLog(prev => [...prev, { id: Date.now() + Math.random(), sender, message, isError }])

  // ---------------- Text to Speech ----------------
  // Always prefer a FEMALE voice so the voice matches Ms. Anjali
  const pickVoice = (lang) => {
    const voices = voicesRef.current
    if (!voices.length) return null
    const low = lang.toLowerCase().replace('_', '-')
    const prefix = low.split('-')[0]
    let cands = voices.filter(v => v.lang.toLowerCase().replace('_', '-') === low)
    if (!cands.length) cands = voices.filter(v => v.lang.toLowerCase().replace('_', '-').startsWith(prefix))
    if (!cands.length) return null
    return [...cands].sort((a, b) => voiceScore(b) - voiceScore(a))[0]
  }

  const stopSpeaking = () => {
    ttsSeqRef.current++
    ttsActiveRef.current = false
    setIsTeacherSpeaking(false)
    if ('speechSynthesis' in window) window.speechSynthesis.cancel()
    if (currentAudioRef.current) {
      try { currentAudioRef.current.pause() } catch { /* noop */ }
      currentAudioRef.current = null
    }
  }

  const browserSpeak = (text, langCode, seq, finish) => {
    if (!('speechSynthesis' in window)) { finish(); return }
    const chunks = chunkForSpeech(text)
    if (!chunks.length) { finish(); return }
    chunks.forEach((chunk, i) => {
      const u = new SpeechSynthesisUtterance(chunk)
      u.lang = langCode
      const voice = pickVoice(langCode)
      if (voice) u.voice = voice
      u.rate = 0.97
      if (i === chunks.length - 1) { u.onend = finish; u.onerror = finish }
      window.speechSynthesis.speak(u)
    })
  }

  // Cloud TTS first (female voice, EVERY language), device voices as fallback
  const speakOutLoud = async (text, langCode) => {
    if (!text) return
    const seq = ++ttsSeqRef.current
    if ('speechSynthesis' in window) window.speechSynthesis.cancel()
    if (currentAudioRef.current) {
      try { currentAudioRef.current.pause() } catch { /* noop */ }
      currentAudioRef.current = null
    }
    const clean = stripEmojis(cleanText(text))
    if (!clean) return
    ttsActiveRef.current = true
    setIsTeacherSpeaking(true)
    const finish = () => {
      if (seq !== ttsSeqRef.current) return
      ttsActiveRef.current = false
      setIsTeacherSpeaking(false)
      if (continuousRef.current && !thinkingRef.current) startListening()
    }
    try {
      const url = await geminiSpeak(clean.slice(0, 4000))
      if (seq !== ttsSeqRef.current) { URL.revokeObjectURL(url); return }
      const audio = new Audio(url)
      currentAudioRef.current = audio
      audio.onended = () => { URL.revokeObjectURL(url); finish() }
      audio.onerror = () => { URL.revokeObjectURL(url); finish() }
      await audio.play()
    } catch (e) {
      console.warn('Cloud TTS unavailable, using device voice:', e)
      if (seq !== ttsSeqRef.current) return
      browserSpeak(clean, langCode, seq, finish)
    }
  }

  // ---------------- AI Tutor (multilingual) ----------------
  const buildSystemPrompt = () => {
    const transcript = transcriptTextRef.current
    return `You are "Ms. Anjali", a kind, warm and encouraging school teacher for children.

CURRENT LESSON VIDEO: "${videoTitleRef.current}"
VIDEO TRANSCRIPT${transcript ? '' : ' (not available yet)'}:
"""${transcript ? transcript.slice(0, 24000) : 'Not available. Answer from the video title and general knowledge.'}"""

TEACHING RULES (use your FULL capabilities):
- The transcript above is your primary source - you deeply understand this video.
- Explain concepts step by step, answer ANY question about the video, give clear real-life examples, create practice questions, and summarize the whole video or any part when asked.
- Hold a natural, flowing conversation and remember what was discussed earlier.
- If a question goes beyond the video, still help the student and gently connect the answer back to the lesson when possible.
- You are a female teacher named Ms. Anjali. Affectionately address the student as "beta" or "child" (or the equivalent in the reply language).
- Always reply in a single short line. Your response must be extremely concise and fit entirely in a single short sentence.
- Plain text only: NO emojis, NO markdown symbols like * or #.

LANGUAGE RULES (VERY IMPORTANT - MULTILINGUAL TUTOR):
1. Detect the language of the student's latest message and normally reply in that SAME language.
2. If the student explicitly requests another language in ANY way (e.g. "give me two examples in Punjabi", "explain in Tamil", "hindi me batao"), reply ENTIRELY in the REQUESTED language immediately.
3. Continue using the most recently requested language for the following replies, until the student writes/speaks in a different language or asks to switch back.
4. You support ALL major languages of the world - Indian, European, Asian, African, Middle Eastern. Any language may be requested and you must reply fluently in it.

OUTPUT FORMAT - respond with ONLY this JSON object and nothing else:
{"reply": "<your full answer in a single short sentence>", "lang": "<BCP-47 code of the language your reply is written in, e.g. hi-IN, pa-IN, ta-IN, en-IN>"}`
  }

  const getAIResponse = async (userInput) => {
    setIsThinking(true)
    thinkingRef.current = true
    try {
      convoRef.current.push({ role: 'user', text: userInput })
      const contents = convoRef.current.slice(-20).map(t => ({ role: t.role, parts: [{ text: t.text }] }))
      const data = await geminiGenerate({
        systemInstruction: { parts: [{ text: buildSystemPrompt() }] },
        contents,
        generationConfig: { responseMimeType: 'application/json', temperature: 0.7, maxOutputTokens: 4096 }
      })
      const raw = extractText(data)
      let reply = raw
      let lang = activeLangRef.current
      try {
        const parsed = JSON.parse(raw.replace(/^```json\s*/i, '').replace(/```\s*$/, '').trim())
        if (parsed && typeof parsed.reply === 'string' && parsed.reply.trim()) {
          reply = parsed.reply
          const l = typeof parsed.lang === 'string' ? parsed.lang.trim() : ''
          if (/^[a-z]{2,3}(-[A-Za-z0-9]{2,6})?$/i.test(l)) lang = l
        }
      } catch { /* model returned plain text - use as-is */ }
      reply = cleanText(reply)
      convoRef.current.push({ role: 'model', text: reply })
      pushMessage('MS. ANJALI', reply)
      // Natural language switching: follow the tutor's language for TTS + next STT turn
      activeLangRef.current = lang
      const supported = resolveSupported(lang)
      if (supported) setSelectedLanguage(supported)
      speakOutLoud(reply, lang)
    } catch (err) {
      console.error(err)
      pushMessage('MS. ANJALI', `Sorry beta, I could not answer right now (${err.message || 'network error'}). Please try again.`, true)
    } finally {
      thinkingRef.current = false
      setIsThinking(false)
      if (continuousRef.current && !ttsActiveRef.current) startListening()
    }
  }

  // ---------------- Speech to Text (continuous conversation) ----------------
  const getSR = () =>
    typeof window !== 'undefined' && (window.SpeechRecognition || window.webkitSpeechRecognition)

  const startListening = () => {
    const SR = getSR()
    if (!SR || !continuousRef.current) return
    try { recognitionRef.current?.abort?.() } catch { /* noop */ }
    const recognition = new SR()
    recognition.lang = activeLangRef.current || selectedLanguage
    recognition.continuous = false
    recognition.interimResults = false
    recognitionRef.current = recognition

    recognition.onstart = () => setIsListening(true)
    recognition.onend = () => {
      setIsListening(false)
      // Restart the loop after silence, unless we are processing or speaking
      if (continuousRef.current && !thinkingRef.current && !ttsActiveRef.current) {
        setTimeout(() => {
          if (continuousRef.current && !thinkingRef.current && !ttsActiveRef.current) startListening()
        }, 300)
      }
    }
    recognition.onerror = (e) => {
      setIsListening(false)
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') {
        continuousRef.current = false
        setIsContinuous(false)
        pushMessage('MS. ANJALI', 'I cannot hear you, beta - microphone permission is blocked. Please allow the microphone and try again, or use Write (Type).', true)
      }
    }
    recognition.onresult = (event) => {
      const text = event.results[0][0].transcript
      thinkingRef.current = true // block onend-restart until AI turn completes
      pushMessage('YOU', text)
      try { recognition.stop() } catch { /* noop */ }
      getAIResponse(text)
    }
    try { recognition.start() } catch { /* already started */ }
  }

  const handleSpeakInteraction = () => {
    const SR = getSR()
    if (!SR) {
      pushMessage('MS. ANJALI', 'Voice input is not supported in this browser, beta. Please use Chrome, or tap Write (Type).', true)
      return
    }
    if (continuousRef.current) {
      // Stop everything
      continuousRef.current = false
      setIsContinuous(false)
      setIsListening(false)
      try { recognitionRef.current?.abort?.() } catch { /* noop */ }
      stopSpeaking()
      return
    }
    continuousRef.current = true
    setIsContinuous(true)
    stopSpeaking()
    startListening()
  }

  const handleSendText = async (e) => {
    e.preventDefault()
    if (!typedMessage.trim() || thinkingRef.current) return
    const msg = typedMessage.trim()
    setTypedMessage('')
    pushMessage('YOU', msg)
    await getAIResponse(msg)
  }

  const handleLanguageChange = (e) => {
    setSelectedLanguage(e.target.value)
    activeLangRef.current = e.target.value
  }

  // ---------------- Video loading ----------------
  const loadNewVideo = ({ ytId = '', url = '', title }) => {
    if (objectUrlRef.current && objectUrlRef.current !== url) {
      URL.revokeObjectURL(objectUrlRef.current)
      objectUrlRef.current = ''
    }
    setVideoId(ytId)
    setLocalUrl(url)
    setVideoTitle(title)
    setIsVideoStarted(true)
    setPlayTime(0)
    setTranscriptSegs([])
    setTranscriptPlainText('')
    setTranslations({})
    setTranscriptLang('original')
    setIsTranslating(false)
    transcriptTextRef.current = ''
    uploadedTranscriptRef.current = false
    setTranscriptStatus(ytId ? 'loading' : 'unavailable')
    convoRef.current.push({ role: 'model', text: `(A new lesson video was loaded: ${title})` })
    pushMessage('MS. ANJALI', `New lesson loaded: ${title}. Let's learn!`)
  }

  const handleLoadVideo = () => {
    if (!inputUrl.trim()) return
    if (modalMode === 'youtube') {
      const id = parseYouTubeId(inputUrl.trim())
      if (id) loadNewVideo({ ytId: id, title: 'New YouTube Lesson' })
      else {
        pushMessage('MS. ANJALI', "That YouTube link doesn't look right, beta. Please paste a full link like https://www.youtube.com/watch?v=XXXXXXXXXXX", true)
      }
    } else {
      loadNewVideo({ url: inputUrl.trim(), title: 'New Video Lesson' })
    }
    setModalMode(null)
    setInputUrl('')
  }

  const handleFileUpload = (e) => {
    const file = e.target.files[0]
    if (!file) return
    const url = URL.createObjectURL(file)
    loadNewVideo({ url, title: file.name })
    objectUrlRef.current = url
    e.target.value = ''
  }

  // Upload the lesson transcript (.srt / .vtt / .txt / .json) - the AI studies it
  const handleTranscriptUpload = async (e) => {
    const file = e.target.files[0]
    if (!file) return
    try {
      const content = await file.text()
      const parsed = parseUploadedTranscript(file.name, content)
      uploadedTranscriptRef.current = true
      setTranslations({})
      setTranscriptLang('original')
      if (parsed.segs && parsed.segs.length) {
        setTranscriptSegs(parsed.segs)
        setTranscriptPlainText('')
        transcriptTextRef.current = parsed.segs.map(x => x.text).join(' ')
      } else {
        setTranscriptSegs([])
        setTranscriptPlainText(parsed.text)
        transcriptTextRef.current = parsed.text
      }
      setTranscriptStatus('ready')
      setShowTranscript(true)
      convoRef.current.push({ role: 'model', text: `(The lesson transcript "${file.name}" was uploaded. I have studied it.)` })
      pushMessage('MS. ANJALI', `Transcript "${file.name}" loaded. I have studied the whole lesson - ask me anything about the video, beta!`)
    } catch (err) {
      console.error(err)
      pushMessage('MS. ANJALI', 'I could not read that transcript file, beta. Please upload a .srt, .vtt, .txt or .json file.', true)
    }
    e.target.value = ''
  }

  const handleStartVideo = () => setIsVideoStarted(true)

  useEffect(() => () => { if (objectUrlRef.current) URL.revokeObjectURL(objectUrlRef.current) }, [])

  // ---------------- Transcript: generation ----------------
  useEffect(() => {
    if (!isYouTube) return
    const seq = ++genSeqRef.current
    fetchYouTubeTranscript(videoId)
      .then(segs => {
        if (genSeqRef.current !== seq || uploadedTranscriptRef.current) return
        if (segs.length) {
          setTranscriptSegs(segs)
          transcriptTextRef.current = segs.map(s => s.text).join(' ')
          setTranscriptStatus('ready')
        } else setTranscriptStatus('unavailable')
      })
      .catch(err => {
        console.warn('Transcript generation failed:', err)
        if (genSeqRef.current === seq) setTranscriptStatus('unavailable')
      })
  }, [videoId, isYouTube])

  // ---------------- Transcript: sync with playback ----------------
  const embedSrc = isYouTube
    ? `https://www.youtube.com/embed/${videoId}?enablejsapi=1&rel=0${isVideoStarted ? '&autoplay=1' : ''}`
    : ''

  // Attach YouTube IFrame API player to poll current time
  useEffect(() => {
    if (!isYouTube) return
    let cancelled = false
    const ensureAPI = () => new Promise(resolve => {
      if (window.YT?.Player) return resolve()
      if (!document.getElementById('yt-iframe-api')) {
        const s = document.createElement('script')
        s.id = 'yt-iframe-api'
        s.src = 'https://www.youtube.com/iframe_api'
        document.head.appendChild(s)
      }
      const t = setInterval(() => {
        if (window.YT?.Player) { clearInterval(t); resolve() }
      }, 150)
    })
    ensureAPI().then(() => {
      if (cancelled || !document.getElementById('yt-frame')) return
      try { ytPlayerRef.current = new window.YT.Player('yt-frame') } catch { /* noop */ }
    })
    return () => {
      cancelled = true
      try { ytPlayerRef.current?.destroy?.() } catch { /* noop */ }
      ytPlayerRef.current = null
    }
  }, [isYouTube, videoId, isVideoStarted])

  useEffect(() => {
    if (!showTranscript || !isYouTube || transcriptSegs.length === 0) return
    const t = setInterval(() => {
      const p = ytPlayerRef.current
      if (p && typeof p.getCurrentTime === 'function') {
        const time = p.getCurrentTime()
        if (typeof time === 'number' && !isNaN(time)) setPlayTime(time)
      }
    }, 300)
    return () => clearInterval(t)
  }, [showTranscript, isYouTube, transcriptSegs])

  const shownSegs = transcriptLang === 'original'
    ? transcriptSegs
    : (translations[transcriptLang]?.segs || transcriptSegs)
  const shownPlain = transcriptLang === 'original'
    ? transcriptPlainText
    : (translations[transcriptLang]?.plain || transcriptPlainText)

  let activeIdx = -1
  for (let i = 0; i < shownSegs.length; i++) {
    if (playTime >= shownSegs[i].start) activeIdx = i
    else break
  }

  useEffect(() => {
    activeSegRef.current?.scrollIntoView({ block: 'nearest', behavior: 'smooth' })
  }, [activeIdx])

  // Multi-language transcript: translate on demand, cache per language
  const handleTranscriptLangChange = async (e) => {
    const code = e.target.value
    setTranscriptLang(code)
    if (code === 'original' || translations[code] || transcriptStatus !== 'ready') return
    setIsTranslating(true)
    try {
      const langName = SUPPORTED_LANGUAGES.find(l => l.code === code)?.name || code
      if (transcriptSegs.length) {
        const out = await translateTexts(transcriptSegs.map(x => x.text), langName, code)
        const segs = transcriptSegs.map((x, i) => ({ ...x, text: out[i] || x.text }))
        setTranslations(prev => ({ ...prev, [code]: { segs, plain: '' } }))
      } else if (transcriptPlainText) {
        const out = await translateTexts([transcriptPlainText.slice(0, 15000)], langName, code)
        setTranslations(prev => ({ ...prev, [code]: { segs: null, plain: out[0] } }))
      }
    } catch (err) {
      console.error(err)
      pushMessage('MS. ANJALI', `Sorry beta, I could not translate the transcript right now (${err.message || 'error'}).`, true)
      setTranscriptLang('original')
    } finally {
      setIsTranslating(false)
    }
  }

  const seekTo = (sec) => {
    if (isYouTube) ytPlayerRef.current?.seekTo?.(sec, true)
    else if (videoElRef.current) videoElRef.current.currentTime = sec
  }

  // ---------------- Render ----------------
  return (
    <div className="classroom-page">

      <header className="classroom-header">
        <div className="logo-section-row">
          <div className="logo-icon-circle"><Play size={16} fill="white" /></div>
          <div className="logo-text-col">
            <span className="logo-subtitle">EDITONE INTERNATIONAL</span>
            <div className="logo-title">
              <span>My World</span>
              <span className="logo-text-divider">—</span>
              <span>Classroom Mode</span>
            </div>
          </div>
        </div>
        <div className="header-actions">
          <button className="header-btn btn-setup"><Settings size={18} /> Lesson Setup</button>
          <button className="header-btn btn-textbook"><ArrowRight size={18} /> Back to Textbook</button>
        </div>
      </header>

      <main className="classroom-container">
        <div className="row">
          <div className="col-left">
            <div className="classroom-card">
              <div className="video-frame-container">
                {!isVideoStarted && (
                  <div className="video-overlay-preview" onClick={handleStartVideo}>
                    <div className="video-header-overlay">
                      <div className="video-info-text">
                        <p className="v-title">{videoTitle}</p>
                        <p className="v-sub">Editone International Pvt Ltd</p>
                      </div>
                    </div>
                    <div className="yt-play-btn"><div className="play-icon-white"></div></div>
                    <div className="video-bottom-left"><Share2 size={18} /></div>
                    <div className="video-bottom-right">
                      <span>Watch on</span>
                      <div className="yt-mini-logo"><Play size={8} fill="white" /></div>
                      <span style={{ fontWeight: 900 }}>YouTube</span>
                    </div>
                  </div>
                )}
                {isYouTube ? (
                  <iframe
                    key={`${videoId}-${isVideoStarted}`}
                    id="yt-frame"
                    width="100%"
                    height="100%"
                    src={embedSrc}
                    frameBorder="0"
                    allow="autoplay; encrypted-media"
                    allowFullScreen
                    title="Lesson video"
                  ></iframe>
                ) : (
                  <video
                    ref={videoElRef}
                    className="html5-video"
                    src={localUrl}
                    controls
                    autoPlay={isVideoStarted}
                    onTimeUpdate={(e) => showTranscript && setPlayTime(e.target.currentTime)}
                  />
                )}
              </div>

              {/* -------- Transcript panel (live, synced) -------- */}
              {showTranscript && (
                <div className="transcript-panel">
                  <div className="transcript-head">
                    <span className="transcript-title"><Captions size={16} /> Live Transcript</span>
                    <div className="t-head-right">
                      {transcriptStatus === 'ready' && activeIdx >= 0 && (
                        <span className="transcript-live-dot">● {formatTime(playTime)}</span>
                      )}
                      <select
                        className="t-lang-select"
                        value={transcriptLang}
                        onChange={handleTranscriptLangChange}
                        disabled={transcriptStatus !== 'ready' || isTranslating}
                        title="Show transcript in another language"
                      >
                        <option value="original">Original</option>
                        {SUPPORTED_LANGUAGES.map(l => <option key={l.code} value={l.code}>{l.name}</option>)}
                      </select>
                    </div>
                  </div>
                  {isTranslating && <p className="transcript-status">Translating transcript…</p>}
                  {transcriptStatus === 'loading' && (
                    <p className="transcript-status">Preparing transcript for this video…</p>
                  )}
                  {transcriptStatus === 'unavailable' && (
                    <p className="transcript-status">Transcript is not available for this video. Use "Upload Transcript" to add one.</p>
                  )}
                  {transcriptStatus === 'ready' && transcriptSegs.length === 0 && transcriptPlainText && (
                    <div className="transcript-body"><p className="t-plain">{shownPlain}</p></div>
                  )}
                  {transcriptStatus === 'ready' && transcriptSegs.length > 0 && (
                    <div className="transcript-body">
                      {shownSegs.map((seg, i) => (
                        <div
                          key={i}
                          ref={i === activeIdx ? activeSegRef : null}
                          className={`t-row ${i === activeIdx ? 'active' : ''}`}
                          onClick={() => seekTo(seg.start)}
                        >
                          <span className="t-time">{formatTime(seg.start)}</span>
                          <span className="t-text">{seg.text}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              <div className="v-actions">
                <button className="dashed-pill-btn" onClick={() => fileInputRef.current?.click()}><Upload size={18} className="icon-orange" /> Upload Video</button>
                <button className="dashed-pill-btn" onClick={() => setModalMode('direct')}><LinkIcon size={18} className="icon-blue" /> Paste Video Link</button>
                <button className="dashed-pill-btn" onClick={() => setModalMode('youtube')}><Play size={18} className="icon-red" /> YouTube Link</button>
                <button className="dashed-pill-btn" onClick={() => transcriptFileRef.current?.click()}><FileText size={18} className="icon-blue" /> Upload Transcript</button>
                <button
                  className={`dashed-pill-btn transcript-toggle ${showTranscript ? 'on' : ''}`}
                  onClick={() => setShowTranscript(v => !v)}
                >
                  <Captions size={18} className="icon-green" /> Transcript: {showTranscript ? 'ON' : 'OFF'}
                </button>
              </div>

              <div className="lesson-pill-row">
                <div className="lesson-pill-styled">
                  <FileText size={18} className="icon-doc-blue" /> {videoTitle}
                </div>
              </div>
              <input type="file" accept="video/*,audio/*" ref={fileInputRef} hidden onChange={handleFileUpload} />
              <input type="file" accept=".srt,.vtt,.txt,.json" ref={transcriptFileRef} hidden onChange={handleTranscriptUpload} />
            </div>
          </div>

          <div className="col-right">
            <div className="classroom-card">
              <div className="teacher-pink-box-large">
                <div className="avatar-xl-circle"><img src={teacherAvatar} alt="Ms. Anjali" /></div>
              </div>

              <div className="interaction-box-premium">
                <div className="int-label-row">
                  <span className="int-label">INTERACTION LANGUAGE</span>
                  <span className="badge-premium">80+ Languages</span>
                </div>
                <select className="premium-select" value={selectedLanguage} onChange={handleLanguageChange}>
                  {SUPPORTED_LANGUAGES.map(lang => <option key={lang.code} value={lang.code}>{lang.name}</option>)}
                </select>
                <p className="lang-hint">Tip: ask in ANY language of the world - e.g. "Give me two examples in Punjabi" or "Explique en français" - and Ms. Anjali replies in that language, in a female voice.</p>
              </div>

              <div className="btn-actions-grid">
                <button className={`btn-premium btn-pink-premium ${(isListening || isTeacherSpeaking) ? 'animate-pulse' : ''}`} onClick={handleSpeakInteraction}>
                  <Mic size={18} /> {
                    isListening
                      ? 'Listening...'
                      : isTeacherSpeaking
                        ? 'Speaking...'
                        : isContinuous
                          ? 'Stop Speaking'
                          : 'Ask (Speak)'
                  }
                </button>
                <button className="btn-premium btn-orange-premium" onClick={() => setShowChatInput(!showChatInput)}>
                  <Send size={18} /> Write (Type)
                </button>
              </div>

              {showChatInput && (
                <form className="premium-pill-input-row" onSubmit={handleSendText}>
                  <div className="pill-input-box">
                    <input type="text" className="pill-input-field" placeholder="Type your question for Ms. Anjali..." value={typedMessage} onChange={(e) => setTypedMessage(e.target.value)} />
                  </div>
                  <button type="submit" className="pill-send-circle"><Send size={22} /></button>
                </form>
              )}

              <div className="premium-chat-bg">
                <div ref={chatTopRef} />
                {isThinking && <div className="dots"><div className="d"></div><div className="d"></div><div className="d"></div></div>}
                {[...chatLog].reverse().map(log => (
                  <div key={log.id} className={`premium-msg-bubble ${log.isError ? 'msg-error' : ''}`}>
                    <div className="premium-msg-name">{log.sender}</div>
                    <p className="premium-msg-text">{log.message}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer className="main-footer-premium">
        <div className="f-info">
          <img src={teacherAvatar} alt="T" className="f-avatar" />
          <p className="f-text"><span className="f-bold">Ms. Anjali says:</span> Let's begin our lesson!</p>
        </div>
        <Volume2 size={24} />
      </footer>

      {modalMode && (
        <div className="premium-modal-overlay">
          <div className="premium-modal-card">
            <div className="modal-header-row">
              <h3 className="modal-title-premium">{modalMode === 'youtube' ? 'Load YouTube Video' : 'Load Video Link'}</h3>
              <button className="modal-close-btn" onClick={() => setModalMode(null)}><X size={20} /></button>
            </div>
            <div className="modal-body-premium">
              <p className="modal-hint-text">
                {modalMode === 'youtube'
                  ? 'Enter YouTube video link (e.g., https://www.youtube.com/watch?v=dQw4w9WgXcQ)'
                  : 'Enter mp4 or direct stream video link'}
              </p>
              <input type="text" className="modal-input-field" placeholder="https://..." value={inputUrl} onChange={(e) => setInputUrl(e.target.value)} />
              <div className="modal-footer-actions">
                <button className="modal-btn modal-btn-grey" onClick={() => setModalMode(null)}>Cancel</button>
                <button className="modal-btn modal-btn-pink" onClick={handleLoadVideo}>Load Video</button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  )
}

export default App
